<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>pagina 2</title>
    <?php require_once 'inc/head.php' ?>
  </head>
  <body>
  <?php require_once 'inc/navbar.php' ?>
    <div>
      <h3>
        Esta es una pagina de prueba 
      </h3>
    </div>
  </body>
</html>
