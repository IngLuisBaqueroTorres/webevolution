<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <?php require_once 'inc/head.php' ?>
  </head>
  <body>
      <?php require_once 'inc/navbar.php' ?>
      <div class="text-center">
        <h1>Bienvenido</h1>
        <h2>
        <?php
        echo $_SESSION['usuario'], "\n";
        echo $_SESSION['apellido'];
         ?> 
        </h2>     
      </div>
  </body>
</html>
