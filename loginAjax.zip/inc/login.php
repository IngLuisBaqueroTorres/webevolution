<?php
session_start();
require_once '../conexion/conexion.php';
if(empty($_POST['usuario']) || empty($_POST['password'])){
  echo '<div class="msj">Algunos datos están vacios</div>';
}else{
  $sql = 'SELECT * FROM usuarios WHERE usuario = "'.$_POST['usuario'].'"';
  $query = $db->prepare($sql);
  $query->execute();
  $result = $query->fetch(PDO::FETCH_ASSOC);
    // var_dump($result);
    //$hash = password_hash(1234, PASSWORD_DEFAULT);
    //echo $hash;
    if(empty($result['usuario'])){
      echo '<div class="msj">Usuario incorrecto</div>';
    }
    else{
      if(count($result) > 0 && password_verify($_POST['password'], $result['clave'])){
        $_SESSION['usuario'] = $result['usuario'];
        $_SESSION['apellido'] = $result['apellido'];
        //header('Location: ../home.php');
        echo 'ok';
      }else{
        echo '<div class="msj">Contraseña incorrecta</div>';
      }
    }
  
}
