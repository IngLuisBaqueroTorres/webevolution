DROP DATABASE evolution;
CREATE DATABASE evolution;
USE evolution;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(20) NOT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(20) COLLATE utf8_spanish_ci NOT NULL,  
  `clave` varchar(255) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `clave`) VALUES
(1, 'juan', 'rodriguez', '$2y$10$FhXzM/piIizE62Yrs9Vfx.GInRtCWKRubutH70J7B0hi6LlUBlt12'),
(2, 'ana', 'estupiñan', '$2y$10$0CfprVZ4xAV2ip7hiNZ0ouF3kKCx2XerZwE/M0A7TQHaSdmwh8sIO'),
(3, 'luis', 'baquero', '$2y$10$FhXzM/piIizE62Yrs9Vfx.GInRtCWKRubutH70J7B0hi6LlUBlt12');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

